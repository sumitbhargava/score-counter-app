package com.example.scorecounter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int scoresA=0;
    int scoresB=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void first (View view) {
     scoresA = scoresA + 3;
     displayForTeamA(scoresA);
    }

    public void second (View view) {
        scoresA = scoresA + 2;
        displayForTeamA(scoresA);
    }

    public void third (View view) {
        scoresA = scoresA + 1;
        displayForTeamA(scoresA);
    }




    public void firstb (View view) {
        scoresB = scoresB + 3;
        displayForTeamB(scoresB);
    }

    public void secondb (View view) {
        scoresB = scoresB + 2;
        displayForTeamB(scoresB);
    }

    public void thirdb (View view) {
        scoresB = scoresB + 1;
        displayForTeamB(scoresB);
    }

    public void reset (View view) {
        scoresA=0;
        scoresB=0;
        displayForTeamA(scoresA);
        displayForTeamB(scoresB);
    }

    /**
     * Displays the given score for Team A.
     */
    public void displayForTeamA(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText(String.valueOf(score));
    }
    /**
     * Displays the given score for Team B.
     */
    public void displayForTeamB(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_score);
        scoreView.setText(String.valueOf(score));
    }
}
